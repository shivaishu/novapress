import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, Bookmark, Check, Clock3, Flame, Heart, Menu, MessageCircle, Search, Share2, Sparkles, ThumbsDown, ThumbsUp, X } from 'lucide-react';

const categories = ['All stories', 'World', 'Technology', 'Business', 'Culture', 'Science', 'Politics'];
const formatDate = (date) => new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date(date));

export default function App() {
  const [articles, setArticles] = useState([]);
  const [category, setCategory] = useState('All stories');
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('nova-user') || 'null'));
  const [token, setToken] = useState(() => localStorage.getItem('nova-token'));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);

  const refresh = async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams();
      if (category !== 'All stories') params.set('category', category);
      if (query.trim()) params.set('q', query.trim());
      const response = await fetch(`/api/articles?${params}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Could not load stories.');
      setArticles(data.articles || []);
    } catch (e) { setError(e.message); setArticles([]); }
    finally { setLoading(false); }
  };
  useEffect(() => { refresh(); }, [category, query]);
  useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(''), 2500); return () => clearTimeout(id); }, [toast]);

  const featured = useMemo(() => articles.find((a) => a.featured) || articles[0], [articles]);
  const remaining = articles.filter((a) => a._id !== featured?._id);

  async function authenticate(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try {
      const response = await fetch(`/api/auth/${authMode === 'login' ? 'login' : 'register'}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message);
      localStorage.setItem('nova-token', data.token); localStorage.setItem('nova-user', JSON.stringify(data.user));
      setToken(data.token); setUser(data.user); setAuthOpen(false); setToast(`Welcome${authMode === 'register' ? ' to Nova Press' : ' back'}, ${data.user.name.split(' ')[0]}.`);
    } catch (e) { setToast(e.message || 'Could not sign in.'); }
  }

  function signOut() { localStorage.removeItem('nova-token'); localStorage.removeItem('nova-user'); setToken(null); setUser(null); setToast('You have signed out.'); }

  async function reactTo(id, value) {
    if (!token) { setAuthOpen(true); setToast('Sign in to react to a story.'); return; }
    try {
      const response = await fetch(`/api/articles/${id}/reactions`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ value }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.message);
      setArticles((list) => list.map((a) => a._id === id ? { ...a, reactions: [...(a.reactions || []).filter((r) => r.user !== user.id), ...(data.mine ? [{ user: user.id, value: data.mine }] : [])] } : a));
      setSelected((a) => a?._id === id ? { ...a, reactions: [...(a.reactions || []).filter((r) => r.user?._id !== user.id && r.user !== user.id), ...(data.mine ? [{ user: user.id, value: data.mine }] : [])] } : a);
    } catch (e) { setToast(e.message); }
  }

  async function comment(id, body) {
    const response = await fetch(`/api/articles/${id}/comments`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ body }) });
    const data = await response.json(); if (!response.ok) throw new Error(data.message);
    setSelected((a) => a?._id === id ? { ...a, comments: [...(a.comments || []), data.comment] } : a);
  }

  return <div className="site-shell">
    <div className="topline"><span><span className="live-dot" /> Independent journalism, fresh perspective</span><span className="topline-right">Friday, October 9, 2026 <span className="topline-sep">·</span> New York 18°</span></div>
    <header className="header">
      <button className="icon-button mobile-trigger" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle navigation">{mobileMenu ? <X /> : <Menu />}</button>
      <a className="brand" href="#top" onClick={() => { setCategory('All stories'); setQuery(''); }}><span className="brand-mark">N</span><span className="brand-copy">NOVA<span>PRESS</span></span></a>
      <nav className={mobileMenu ? 'main-nav open' : 'main-nav'}>{categories.slice(1).map((item) => <button key={item} className={category === item ? 'nav-item active' : 'nav-item'} onClick={() => { setCategory(item); setMobileMenu(false); document.getElementById('latest')?.scrollIntoView({ behavior: 'smooth' }); }}>{item}</button>)}</nav>
      <div className="header-actions">
        {searchOpen ? <form className="search-form" onSubmit={(e) => { e.preventDefault(); setSearchOpen(false); document.getElementById('latest')?.scrollIntoView({ behavior: 'smooth' }); }}><input autoFocus placeholder="Search stories" value={query} onChange={(e) => setQuery(e.target.value)} /><button className="icon-button" type="button" onClick={() => { setSearchOpen(false); setQuery(''); }} aria-label="Close search"><X /></button></form> : <button className="icon-button search-trigger" onClick={() => setSearchOpen(true)} aria-label="Search"><Search /></button>}
        {user?.role === 'editor' && <button className="signin write-button" onClick={() => setEditorOpen(true)}>Write a story <span>+</span></button>}
        {user ? <button className="profile-chip" onClick={signOut} title="Click to sign out"><span>{user.name.charAt(0).toUpperCase()}</span><b>{user.name.split(' ')[0]}</b></button> : <button className="signin" onClick={() => { setAuthMode('login'); setAuthOpen(true); }}>Sign in <ArrowRight size={15} /></button>}
      </div>
    </header>
    <main id="top">
      <section className="hero-intro"><div className="eyebrow"><span className="eyebrow-line" /> THE WORLD, IN FOCUS <span className="eyebrow-line" /></div><h1>Stories that move<br /><em>the world forward.</em></h1><p>Clear-eyed journalism for curious minds. What matters, why it matters, and what comes next.</p><a className="explore-link" href="#latest">Explore today’s stories <ArrowDown size={15} /></a></section>

      <section className="lead-section" aria-label="Top story"><div className="section-kicker"><span><Flame size={15} /> THE DAILY EDITION</span><span className="kicker-rule" /><span className="edition-date">VOL. 01 <i>—</i> NO. 284</span></div>
        {loading && articles.length === 0 ? <div className="skeleton-feature" /> : featured ? <div className="lead-card">
          <button className="lead-image image-button" onClick={() => setSelected(featured)} style={{ backgroundImage: `url(${featured.image})` }} aria-label={`Read ${featured.title}`}><span className="image-label">EDITOR’S PICK</span></button>
          <div className="lead-copy"><span className="category-label">{featured.category} <span> / </span> FEATURED</span><h2>{featured.title}</h2><p>{featured.excerpt}</p><div className="byline"><span className="avatar">{featured.author?.name?.[0] || 'N'}</span><span>By <b>{featured.author?.name || 'Nova Press'}</b></span><span className="byline-dot">·</span><span>{formatDate(featured.createdAt)}</span><span className="read-time"><Clock3 size={14} /> {featured.readMinutes || 4} min read</span></div><button className="read-link" onClick={() => setSelected(featured)}>Read the full story <ArrowRight size={16} /></button></div>
        </div> : <div className="empty-lead"><Sparkles /><div><b>Your first edition is waiting.</b><span>{error || 'Add the sample stories to bring Nova Press to life.'}</span></div></div>}
      </section>

      <section className="latest-section" id="latest"><div className="section-heading"><div><div className="section-overline">HANDPICKED FOR YOU</div><h2>{query ? `Search results for “${query}”` : category === 'All stories' ? 'The latest stories' : `Latest in ${category}`}</h2></div><div className="heading-side"><span>{articles.length} stories <i>·</i> Updated just now</span><button className="text-arrow" onClick={() => { setCategory('All stories'); setQuery(''); }}>View all <ArrowRight size={15} /></button></div></div>
        <div className="category-scroll">{categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={category === item ? 'category-pill selected' : 'category-pill'}>{item}</button>)}</div>
        {error && articles.length === 0 ? <div className="notice"><span className="notice-icon">!</span><div><b>We can’t reach the newsroom just yet.</b><span>Start the API and MongoDB, then refresh this page. {error}</span></div><button onClick={refresh}>Try again</button></div> : loading ? <div className="article-grid">{[1, 2, 3].map((i) => <div className="skeleton-card" key={i} />)}</div> : remaining.length ? <div className="article-grid">{remaining.map((article) => <ArticleCard key={article._id} article={article} onOpen={setSelected} />)}</div> : articles.length ? null : <div className="empty-state"><div className="empty-illustration"><Search /></div><h3>No stories found</h3><p>Try a different search or choose another section.</p><button className="text-arrow" onClick={() => { setCategory('All stories'); setQuery(''); }}>Clear filters <ArrowRight size={15} /></button></div>}
        {articles.length > 4 && <button className="load-more" onClick={() => setToast('You’re all caught up with today’s edition.')}>You’re all caught up <Check size={15} /></button>}
      </section>

      <section className="newsletter"><div className="newsletter-orb">N</div><div><div className="section-overline">A LITTLE CLARITY IN YOUR INBOX</div><h2>The stories worth<br />your morning.</h2><p>Our editors’ essential reads, delivered every weekday. No noise, just perspective.</p></div><form onSubmit={(e) => { e.preventDefault(); setToast('Thanks for subscribing. Look out for the next edition.'); e.currentTarget.reset(); }}><label htmlFor="newsletter-email">YOUR EMAIL ADDRESS</label><div className="email-field"><input id="newsletter-email" required type="email" placeholder="you@example.com" /><button aria-label="Subscribe"><ArrowRight /></button></div><span className="privacy-note">By subscribing, you agree to our Privacy Policy.</span></form></section>
    </main>
    <footer className="footer"><a className="brand footer-brand" href="#top"><span className="brand-mark">N</span><span className="brand-copy">NOVA<span>PRESS</span></span></a><span>Independent by nature. Curious by design.</span><div><a href="#latest">About</a><a href="#latest">Contact</a><a href="#latest">Privacy</a><span>© 2026 Nova Press</span></div></footer>
    {selected && <ArticleModal article={selected} user={user} token={token} onClose={() => setSelected(null)} onReact={reactTo} onComment={comment} onSignIn={() => { setSelected(null); setAuthOpen(true); }} />}
    {authOpen && <AuthModal mode={authMode} setMode={setAuthMode} onClose={() => setAuthOpen(false)} onSubmit={authenticate} />}
    {editorOpen && <EditorComposer token={token} onClose={() => setEditorOpen(false)} onPublished={() => { setEditorOpen(false); setCategory('All stories'); setQuery(''); refresh(); setToast('Your story is live.'); }} />}
    {toast && <div className="toast"><Check size={16} /> {toast}</div>}
  </div>;
}

function ArticleCard({ article, onOpen }) {
  return <article className="article-card"><button className="card-image image-button" onClick={() => onOpen(article)} style={{ backgroundImage: `url(${article.image})` }} aria-label={`Read ${article.title}`}><span>{article.category}</span></button><div className="card-content"><div className="card-meta"><span>{formatDate(article.createdAt)}</span><span className="meta-dot">·</span><span><Clock3 size={12} /> {article.readMinutes || 4} min</span></div><button className="card-title" onClick={() => onOpen(article)}>{article.title}</button><p>{article.excerpt}</p><div className="card-bottom"><div className="mini-author"><span className="mini-avatar">{article.author?.name?.[0] || 'N'}</span> {article.author?.name || 'Nova Press'}</div><div className="card-stats"><span><Heart size={14} /> {article.reactions?.filter((r) => r.value === 'like').length || 0}</span><span><MessageCircle size={14} /> {article.comments?.length || 0}</span></div><button className="bookmark-button" onClick={() => onOpen(article)} aria-label="Open story"><ArrowRight size={16} /></button></div></div></article>;
}

function ArticleModal({ article, user, token, onClose, onReact, onComment, onSignIn }) {
  const [body, setBody] = useState(''); const [busy, setBusy] = useState(false); const [shareLabel, setShareLabel] = useState('Share');
  const mine = article.reactions?.find((r) => (r.user?._id || r.user) === user?.id)?.value;
  const likes = article.reactions?.filter((r) => r.value === 'like').length || 0;
  async function submit(event) { event.preventDefault(); if (!token) return onSignIn(); setBusy(true); try { await onComment(article._id, body); setBody(''); } catch (e) { alert(e.message); } finally { setBusy(false); } }
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><article className="story-modal"><button className="modal-close icon-button" onClick={onClose} aria-label="Close story"><X /></button><div className="modal-hero" style={{ backgroundImage: `url(${article.image})` }} /><div className="modal-body"><button className="back-link" onClick={onClose}><ArrowLeft size={15} /> BACK TO THE EDITION</button><span className="category-label modal-category">{article.category} <span> / </span> {formatDate(article.createdAt)}</span><h1>{article.title}</h1><p className="modal-deck">{article.excerpt}</p><div className="modal-byline"><span className="avatar">{article.author?.name?.[0] || 'N'}</span><span>By <b>{article.author?.name || 'Nova Press'}</b><small>{article.readMinutes || 4} min read</small></span><button className="share-button" onClick={async () => { try { await navigator.clipboard.writeText(window.location.href); setShareLabel('Copied'); setTimeout(() => setShareLabel('Share'), 1500); } catch { setShareLabel('Copy unavailable'); } }}><Share2 size={15} /> {shareLabel}</button></div><div className="article-prose">{article.body?.split('\n\n').map((paragraph, i) => <p key={i}>{paragraph}</p>)}</div><div className="reaction-bar"><span>Was this story useful?</span><button className={mine === 'like' ? 'react-button chosen' : 'react-button'} onClick={() => onReact(article._id, 'like')}><ThumbsUp size={16} /> Helpful <b>{likes}</b></button><button className={mine === 'dislike' ? 'react-button chosen' : 'react-button'} onClick={() => onReact(article._id, 'dislike')}><ThumbsDown size={16} /> Not for me</button></div><section className="comments"><h3>Join the conversation <span>{article.comments?.length || 0}</span></h3><form onSubmit={submit} className="comment-form"><textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={token ? 'Share a thoughtful comment…' : 'Sign in to join the conversation'} maxLength={1000} /><button disabled={busy || !body.trim()}>{busy ? 'Posting…' : 'Post comment'} <ArrowRight size={15} /></button></form><div className="comment-list">{article.comments?.map((comment) => <div className="comment" key={comment._id || comment.createdAt}><span className="mini-avatar">{comment.author?.name?.[0] || 'N'}</span><div><b>{comment.author?.name || 'Reader'}</b><p>{comment.body}</p></div></div>)}</div></section></div></article></div>;
}

function AuthModal({ mode, setMode, onClose, onSubmit }) {
  return <div className="modal-backdrop auth-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="auth-modal"><button className="modal-close icon-button" onClick={onClose} aria-label="Close"><X /></button><span className="auth-mark">N</span><div className="section-overline">WELCOME TO NOVA PRESS</div><h2>{mode === 'login' ? 'Good to have you back.' : 'Make room for perspective.'}</h2><p>{mode === 'login' ? 'Sign in to save your place in the conversation.' : 'Create your reader account and join the conversation.'}</p><form onSubmit={onSubmit}>{mode === 'register' && <label>Your name<input required name="name" placeholder="Alex Morgan" autoComplete="name" /></label>}<label>Email address<input required type="email" name="email" placeholder="you@example.com" autoComplete="email" /></label><label>Password<input required type="password" name="password" minLength="8" placeholder="At least 8 characters" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label><button className="auth-submit">{mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={16} /></button></form><div className="auth-switch">{mode === 'login' ? 'New to Nova Press?' : 'Already a reader?'} <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Create an account' : 'Sign in'}</button></div><div className="auth-legal">By continuing, you agree to our Terms of Service and Privacy Policy.</div></section></div>;
}

function EditorComposer({ token, onClose, onPublished }) {
  const [saving, setSaving] = useState(false); const [error, setError] = useState('');
  async function submit(event) {
    event.preventDefault(); setSaving(true); setError('');
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    payload.readMinutes = Number(payload.readMinutes); payload.featured = form.has('featured'); payload.published = true;
    try {
      const response = await fetch('/api/articles', { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await response.json(); if (!response.ok) throw new Error(data.message || 'Could not publish this story.');
      onPublished();
    } catch (e) { setError(e.message); }
    finally { setSaving(false); }
  }
  return <div className="modal-backdrop auth-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="editor-modal"><button className="modal-close icon-button" onClick={onClose} aria-label="Close editor"><X /></button><div className="section-overline">NOVA PRESS / EDITOR DESK</div><h2>Publish a story</h2><p>Write with care. You can refine the story later.</p><form onSubmit={submit}>
    <label>Headline<input required name="title" maxLength="150" placeholder="A clear, thoughtful headline" /></label>
    <label>Short introduction<textarea required name="excerpt" maxLength="300" rows="2" placeholder="What should readers know first?" /></label>
    <div className="editor-row"><label>Section<select name="category" defaultValue="World">{categories.slice(1).map((item) => <option key={item}>{item}</option>)}</select></label><label>Reading time<select name="readMinutes" defaultValue="4">{[3,4,5,6,7,8,10,12].map((n) => <option key={n} value={n}>{n} minutes</option>)}</select></label></div>
    <label>Cover image URL<input name="image" type="url" placeholder="https://… (optional)" /></label>
    <label>Full story<textarea required name="body" rows="7" placeholder="Write the full article. Separate paragraphs with a blank line." /></label>
    <label className="feature-check"><input type="checkbox" name="featured" /> Feature this story at the top of the edition</label>
    {error && <div className="editor-error">{error}</div>}
    <button className="auth-submit" disabled={saving}>{saving ? 'Publishing…' : 'Publish story'} <ArrowRight size={16} /></button>
  </form></section></div>;
}
